import firebase from 'firebase/compat/app' // For Firebase JS SDK v7.20.0 and later, measurementId is optional

import 'firebase/compat/auth'

const firebaseConfig = {
  apiKey: "AIzaSyBZk--U9qLgpZrb_5A4pb3-Ff27p6vELzI",
  authDomain: "yt-videos-c1f70.firebaseapp.com",
  projectId: "yt-videos-c1f70",
  storageBucket: "yt-videos-c1f70.appspot.com",
  messagingSenderId: "435455141989",
  appId: "1:435455141989:web:980d684b458033de4f7e8c",
};

firebase.initializeApp(firebaseConfig)

export default firebase.auth()
