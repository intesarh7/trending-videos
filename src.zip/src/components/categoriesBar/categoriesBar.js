import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Helmet } from 'react-helmet'

import { getPopularVideos, getVideosByCategory } from '../../redux/actions/videos.action'
import './_categoriesBar.scss'
import { Link } from 'react-router-dom/cjs/react-router-dom.min'

const keywords = [
   'All' ,
   'Latest Videos' ,
   'Latest Movies',
   'Latest Shorts',
   'South Indian Movies',
   'Latest Songs',
   'Bollywood News',
   'Bollywod Movies',
   'Hollywood Movies',
   'Pewdiepie',
   'Asmr',
   'BTS',
   'Billie Eilish',
   'wwe',
   'Ashish Chanchlani',
   'Punjabi Songs',
   'Dynamo Gaming',
   'WhatsApp Status',
]

const CategoriesBar = () => {
   const [activeElement, setActiveElement] = useState('All')

   const dispatch = useDispatch()
   const handleClick = value => {
      setActiveElement(value)
      if (value === 'All') {
         dispatch(getPopularVideos())
      } else {
         dispatch(getVideosByCategory(value))
      }
   }
   return (
      
      <div className='categoriesBar'>
         <Helmet>
            <meta charset="UTF-8" />
            <meta name="description" content="Free Web tutorials"/>
            <meta name="keywords" content={keywords}/>
         </Helmet>
         <Helmet>
         {keywords.map((value, i) => (
            <Link to={value}>
            <span>
               {value}
            </span>
            </Link>
         ))}
         </Helmet>
         {keywords.map((value, i) => (
            <Link to={value}>
            <span
               onClick={() => handleClick(value)}
               key={i}
               className={activeElement === value ? 'active' : ''}>
               {value}
            </span>
            </Link>
         ))}
      </div>
   )
}

export default CategoriesBar
