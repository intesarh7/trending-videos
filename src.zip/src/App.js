import React, { useEffect, useState } from 'react'
import { Container } from 'react-bootstrap'

import Header from './components/header/Header'
import HomeScreen from './components/screens/HomeScreen'
import LoginScreen from './components/screens/loginScreen/LoginScreen'
import Sidebar from './components/sidebar/Sidebar'

import { Redirect, Route, Switch } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { useHistory } from 'react-router-dom'
import WatchScreen from './components/screens/watchScreen/WatchScreen'
import SearchScreen from './components/screens/SearchScreen'
import SubscriptionsScreen from './components/screens/subscriptionsScreen/SubscriptionsScreen'


const Layout = ({ children }) => {
  
  const [sidebar, toggleSidebar] = useState(false)

  const handleToggleSidebar = () => toggleSidebar(value => !value)

  return (
     <>
        <Header handleToggleSidebar={handleToggleSidebar} />
        <div className='app__container'>
           <Sidebar
              sidebar={sidebar}
              handleToggleSidebar={handleToggleSidebar}
           />
           <Container fluid className='app__main '>
              {children}
           </Container>
        </div>
     </>
  )
}

const App =() => {


  const { accessToken, loading } = useSelector(state => state.auth)

   const history = useHistory()

   useEffect(() => {
      if (!loading && !accessToken) {
         //history.push('/auth')
         history.push('/')
      }
   }, [accessToken, loading, history])

  return (
     
      <Switch>
        <Route path='/' exact>
          <Layout>
            <HomeScreen/>
          </Layout>
        </Route>

        <Route path='/auth'>
            <LoginScreen/>        
        </Route>

        <Route path='/search/:query'>
          <Layout>
          <SearchScreen />
          </Layout>
        </Route>
        
        <Route path='/watch/:id'>
          <Layout>
          <WatchScreen/>
          </Layout>
        </Route>

        <Route path='/feed/:subscription'>
          <Layout>
           <SubscriptionsScreen/>
          </Layout>
        </Route>

        <Route path='/channel/:channelId'>
          <Layout>
          channel Screen
          </Layout>
        </Route>

        <Redirect to="/"/>
      </Switch>
    
  )
}

export default App
