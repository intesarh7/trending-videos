import axios from 'axios'
console.log(process.env.REACT_YT_API_KEY)
const request = axios.create({
   baseURL: 'https://youtube.googleapis.com/youtube/v3/',
   params: {
      key: 'AIzaSyBTQ8uJluN1ThUtMg17vt75vHFrLgakOHc',
      //key: 'AIzaSyCrD-rk7v8nXUkcNW_Ci60LfgW0R8cHaPI'
      //key: process.env.REACT_YT_API_KEY
   },
})

export default request